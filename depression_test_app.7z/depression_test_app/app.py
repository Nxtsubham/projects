from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import os
import numpy as np
import joblib
import mne

app = Flask(__name__)

# Database setup
def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            activity TEXT,
            stress_level INTEGER,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

# EEG processing and depression detection
def process_eeg(file_path):
    # Load EEG data (example: .set file format)
    raw = mne.io.read_raw_eeglab(file_path)
    raw.filter(1, 40)  # Bandpass filter

    # Extract features (example: spectral power)
    psd, freqs = mne.time_frequency.psd_welch(raw, fmin=1, fmax=40)
    features = np.mean(psd, axis=1)

    # Load pre-trained model
    model = joblib.load('models/brain.h5')
    prediction = model.predict([features])
    return prediction[0]

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/get_activities')
def get_activities():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM activities ORDER BY timestamp DESC')
    activities = cursor.fetchall()
    conn.close()

    # Convert activities to a list of dictionaries
    activity_list = []
    for activity in activities:
        activity_list.append({
            'activity': activity[2],
            'stress_level': activity[3],
            'timestamp': activity[4]
        })
    return jsonify(activity_list)

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'eeg_file' not in request.files:
        return redirect(url_for('index'))

    eeg_file = request.files['eeg_file']
    if eeg_file.filename == '':
        return redirect(url_for('index'))

    file_path = os.path.join('static/uploads', eeg_file.filename)
    eeg_file.save(file_path)

    result = process_eeg(file_path)
    return render_template('results.html', result=result)

@app.route('/log_activity', methods=['POST'])
def log_activity():
    user_id = 1  # Replace with actual user ID (e.g., from session)
    activity = request.form['activity']
    stress_level = int(request.form['stress_level'])

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO activities (user_id, activity, stress_level)
        VALUES (?, ?, ?)
    ''', (user_id, activity, stress_level))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)