// Validate EEG file upload form
document.querySelector('form').addEventListener('submit', function (event) {
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput.files.length === 0) {
        alert('Please upload an EEG file.');
        event.preventDefault(); // Prevent form submission
    }
});

// Example: Fetch activity logs dynamically (AJAX)
function fetchActivities() {
    fetch('/get_activities')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector('table tbody');
            tableBody.innerHTML = ''; // Clear existing rows
            data.forEach(activity => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${activity.activity}</td>
                    <td>${activity.stress_level}</td>
                    <td>${activity.timestamp}</td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching activities:', error));
}

// Fetch activities every 5 seconds (optional)
setInterval(fetchActivities, 5000);