from flask import Flask, render_template, request
import numpy as np
from keras.models import load_model
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
from keras.losses import MeanSquaredError

app = Flask(__name__)

# Load the model and scalers
model = load_model('electricity_demand_model.h5', compile=False)
model.compile(optimizer='adam', loss=MeanSquaredError())

# Load data to fit scalers
data = pd.read_csv('my_final_data.csv')
data.ffill(inplace=True)
data_numeric = data.select_dtypes(include=[np.number])
data_features = data_numeric.drop(columns=['Hourly Demand Met (in MW)', 'Unnamed: 0', 'Unnamed: 0.1'])
data_target = data_numeric[['Hourly Demand Met (in MW)']]

# Initialize and fit scalers
feature_scaler = MinMaxScaler()
target_scaler = MinMaxScaler()
feature_scaler.fit(data_features)
target_scaler.fit(data_target)

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    if request.method == 'POST':
        # Get input values from the form
        input_values = [
            float(request.form['temp']),
            float(request.form['humidity']),
            float(request.form['wind_speed']),
            float(request.form['visibility']),
            float(request.form['pressure']),
            float(request.form['precipitation']),
            float(request.form['hour']),
            float(request.form['day']),
            float(request.form['month']),
            float(request.form['year']),
            float(request.form['population'])
        ]

        # Create DataFrame from input values
        example_input = pd.DataFrame([input_values], columns=data_features.columns)

        # Scale input
        example_input_scaled = feature_scaler.transform(example_input)
        example_input_scaled = np.reshape(example_input_scaled, (1, 1, example_input_scaled.shape[1]))

        # Predict
        prediction = model.predict(example_input_scaled)
        predicted_actual = target_scaler.inverse_transform(prediction)[0, 0]
        prediction = f"Predicted Electricity Consumption (Actual): {predicted_actual:.2f} MW"

    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)